#include <stdio.h>
#include <stdlib.h>

int main()
{
    int num1 = 20;
    int *numPtr1;

    numPtr1 = &num1;
    // 일반 변수의 메모리 주소를 할당함
    // -> 변수는 메모리 주소가 stack에 생성됨

    int *numPtr2;

    numPtr2 = malloc(sizeof(int));
    // malloc 함수는 heap부분의 메모리 사용
    // 차이점(메모리 해재) : malloc 함수를 사용하여 heap에서 할당한 메모리는 반드시 해재를 해주어야 한다.

    printf("%p\n", numPtr1);
    printf("%p\n", numPtr2);

    free(numPtr2); // 메모리 해재

    return 0;
}

// 메모리를 사용하려면 malloc(memory allocation) 함수로 사용할 메모리 공간을 확보해야 한다.