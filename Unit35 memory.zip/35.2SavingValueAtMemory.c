#include <stdio.h>
#include <stdlib.h>

int main()
{
    int *numPtr;

    numPtr = malloc(sizeof(int));

    *numPtr = 10;

    printf("%d\n", *numPtr); // 10 : 포인터를 역참조하여 메모리에 저장된 값을 출력

    free(numPtr);

    return 0;
}