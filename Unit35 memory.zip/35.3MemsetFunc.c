#include <stdio.h>
#include <stdlib.h> // malloc, free 함수가 선언된 헤더파일
#include <string.h> // memset 함수가 선언된 헤더파일



int main()
{
// 원래 포인터를 역참조해 값을 할당할 때는 자료형 크기만큼만 할당할 수 있음
// 만약 int형 포인터면 4바이트만큼 크기 할당
// memset함수를 사용하면 메모리에서 내용을 원하는 크기만큼 특정값으로 설정 가능
// byte 단위
// memset(포인터, 설정할값, 크기);
    long long *numPtr = malloc(sizeof(long long));

    memset(numPtr, 0x27, 8);

    printf("0x%llx\n", *numPtr);

    free(numPtr);

    return 0;
}