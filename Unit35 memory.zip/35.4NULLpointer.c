#include <stdio.h>

// 메모리가 할당된 포인터도 있지만, 메모리가 할당되지 않은 포인터도 있을 것이다

int main()
{
    int *numPtr1 = NULL;

    printf("%p\n", numPtr1);

    return 0;
}

// 실무에서는
/*

if (ptr == NULL)
{
    ptr = malloc(1024);
}

NULL포인터면 메모리를 할당하는 패턴을 주로 사용
*/

// 일단은 메모리를 할당했으면 해제해야 된다는 점만 기억하면 됩니다.