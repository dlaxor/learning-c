#include <stdio.h>

int main()
{
    int numArr[3][4] = {
        { 11, 22, 33, 44 },
        { 55, 66, 77, 88 },
        { 99, 110, 121, 132 }
    };

    // 2차원 배열을 포인터에 담는 법
    // 자료형 (*포인터이름)[가로크기];

    int (*ArrPtr)[4] = numArr;
    // 배열 자체가 주소라서 그냥 이렇게하믄댐

    printf("%d\n", ArrPtr[1][2]);
    // 포인터가 주소니까 포인터로 인덱싱가능

    printf("%d\n", sizeof(numArr));

    printf("%d\n", sizeof(ArrPtr));

    printf("%p\n", *ArrPtr);
    // 2차원 배열 포인터를 역참조하면 세로 첫번째의 주소가 나온다 (배열 == 주소)

    printf("%p\n", *numArr);
    // 2차원 배열을 역참조하면 세로 첫번째의 주소가 나온다

// 3차원 배열 (참고)
    int numArr2[2][3][4] = {
        {
            {11, 22, 33, 44},
            {55, 66, 77, 88},
            {99, 110, 121, 132}
        },
        {
            {111, 122, 133, 144},
            {155, 166, 177, 188},
            {199, 1110, 1121, 1132}
        }
    };

    printf("%d\n", numArr2[0][2][1]);

    numArr2[1][1][2] = 0;

    int depth = sizeof(numArr2) / sizeof(numArr2[0]);

    int row = sizeof(numArr2[0]) / sizeof(numArr2[0][0]);

    int col = sizeof(numArr2[0][0]) / sizeof(int);

    int (*numPtr)[3][4] = numArr2;

    return 0;
}