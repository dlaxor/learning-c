#include <stdio.h>

int main()
{
    int numArr1[3][4] = {
        {11, 22, 33, 44},
        {55, 66, 77, 88},
        {99, 110, 121, 132}
    };

    printf("%d\n", sizeof(numArr1)); // 4 * 12 = 48

    int col = sizeof(numArr1[0]) / sizeof(int);
    // 열의 크기 : 가로 한줄의 크기 / 요소 크기

    int row = sizeof(numArr1) / sizeof(numArr1[0]);
    // 행의 크기 : 전체 배열의 크기 / 가로 한줄의 크기

    printf("%d\n", row);
    printf("%d\n", col);

    return 0;
}