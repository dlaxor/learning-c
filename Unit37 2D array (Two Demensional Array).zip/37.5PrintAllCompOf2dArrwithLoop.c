#include <stdio.h>

int main()
{
    int numArr1[3][4] = {
        {11, 22, 33, 44},
        {55, 66, 77, 88},
        {99, 110, 121, 132}
    };

    int row = sizeof(numArr1) / sizeof(numArr1[0]);
    int col = sizeof(numArr1[0]) / sizeof(int);

    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            printf("%d ", numArr1[i][j]);
        }
        printf("\n");
    }

    printf("\n");

    // 역순 출력
    for (int i = row - 1; i >= 0; i--)
    {
        for (int j = col - 1; j >= 0; j--)
        {
            printf("%d ", numArr1[i][j]);
        }
        printf("\n");
    }

    return 0;
}