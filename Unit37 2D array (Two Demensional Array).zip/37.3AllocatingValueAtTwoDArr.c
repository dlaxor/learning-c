#include <stdio.h>
#define row 3
#define col 4

void TwoDArrPrinter(int NameOfArr[row][col])
{

    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            printf("%d ", NameOfArr[i][j]);
        }
        printf("\n");
    }
}

int main()
{
    int TwoDArr1[row][col];
    int value = 11;

    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            TwoDArr1[i][j] = value; // 값 할당하는법
            value += 1;
        }
    }

    TwoDArrPrinter(TwoDArr1);

    return 0;
}