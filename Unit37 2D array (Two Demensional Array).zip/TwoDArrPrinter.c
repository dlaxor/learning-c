#include <stdio.h>
#define row 3
#define col 4

// column : 열, row : 행

void TwoDArrPrinter(int NameOfArr[row][col])
{

    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            printf("%d ", NameOfArr[i][j]);
        }
        printf("\n");
    }
}