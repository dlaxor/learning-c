#include <stdio.h>

int main()
{

    // NameOfArr[세로요소 크기][가로요소 크기]
    int TwoDArr[3][4] = {
        {1, 2, 3, 4},
        {5, 6, 7, 8},
        {9, 10, 11, 12}
    };

    int num1 = TwoDArr[1][2]; // 7
    // 인덱싱도 [세로][가로]

    printf("%d\n", num1);

    return 0;
}