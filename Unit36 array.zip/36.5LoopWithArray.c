#include <stdio.h>

int main()
{
// 순행출력
    // int Arr1[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

    // for (int i = 0; i < sizeof(Arr1) / sizeof(int); i++)
    // {
    //     printf("%d\n", Arr1[i]);
    // }
    // return 0;

// 역출력 1
    // int Arr2[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

    // for (int i = 0; i < sizeof(Arr2) / sizeof(int); i++)
    // {
    //     printf("%d\n", Arr2[sizeof(Arr2) / sizeof(int) - 1 - i]);
    // }
    // return 0;
// 역출력 2
    int Arr3[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

    for (int i = sizeof(Arr3) / sizeof(int) - 1; i >= 0; i--)
    {
        printf("%d\n", Arr3[i]);
    }
    return 0;
}