#include <stdio.h>

int main()
{
    int Arr1[] = {1, 2, 3, 4, 5};

    for (int i = 0; i < sizeof(Arr1) / sizeof(int); i++)
    {
        Arr1[i] *= 2;
    }
    for (int i = 0; i < sizeof(Arr1) / sizeof(int); i++)
    {
        printf("%d\n", Arr1[i]);
    }

    return 0;
}