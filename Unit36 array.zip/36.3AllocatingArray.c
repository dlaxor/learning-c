#include <stdio.h>

int main()
{
    int numArr[10];

    numArr[0] = 1; // 값 할당
    numArr[9] = 10;

    printf("%d\n", numArr[0]); // 11
    printf("%d\n", numArr[1]); // 쓰값
    printf("%d\n", numArr[2]); // 쓰값
    printf("%d\n", numArr[-1]); // 파이썬이었으면 10이 나왔을 것. 하지만 c는 -1을 인덱싱한다고 거꾸로 가지 않는다

    return 0;
}