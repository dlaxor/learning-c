#include <stdio.h>

int main()
{
    int decimal = 0;
    int binaryArr[4] = { 1, 1, 0, 1 };    // 1101 순서대로 저장됨

    int position = 0;
    for (int i = sizeof(binaryArr) / sizeof(int) - 1; i >= 0; i--)
    {
        if (binaryArr[i] == 1)
            decimal += 1 << position;

        position++;
    }

    printf("%d\n", decimal);

    return 0;

// 첫번째 요소부터 인덱싱하는 버전
    // int decimal = 0;
    // int binaryArr[4] = { 1, 1, 0, 1 };    // 1101 순서대로 저장됨

    // int position = sizeof(binaryArr) / sizeof(int) - 1;
    // for (int i = 0; i < sizeof(binaryArr) / sizeof(int); i++)
    // {
    //     if (binaryArr[i] == 1)
    //         decimal += 1 << position;

    //     position--;
    // }

    // printf("%d\n", decimal);

    // return 0;
}