#include <stdio.h>

int main()
{
    float scores[10] = { 67.2f, 84.3f, 97.0f, 87.1f, 71.9f, 63.0f, 90.1f, 88.0f, 79.7f, 95.3f };
    float sum = 0.0f;
    float average;

    for (int i = 0; i < sizeof(scores) / sizeof(float); i++)
    {
        sum += scores[i];
    }

    average = sum / (sizeof(scores) / sizeof(float));
    // 정수, 실수가 섞인 연산에서는 괄호를 잘 쓰기

    printf("%f\n", average);

    return 0;
}