#include <stdio.h>

int main()
{
    int numArr[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

    printf("%d\n", sizeof(numArr));
    // 4바이트 요소가 10개이므로 40 출력

    printf("%d\n", sizeof(numArr) / sizeof(int));
    // 단순 요소개수를 원한다면 sizeof(배열) / sizeof(요소자료형)을 해야한다
    return 0;
}