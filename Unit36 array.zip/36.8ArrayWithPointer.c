#include <stdio.h>

int main()
{
    int Arr1[10] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    // 배열은 사실 첫 번쨰의 요소의 주솟값만 담고 있다.
    // 즉, 배열은 주소값이기에 포인터에 넣을 수 있다.

    int *ArrPtr = Arr1;

    printf("%d\n", *ArrPtr); // 1 : 배열의 주소가 들어있는 포인터를 역참조하면 배열의 첫번째 요소에 접근
    
    printf("%d\n", *Arr1); // 배열이 주소값이기에 배열을 역참조하면 값을 가져올 수 있다

    printf("%d\n", ArrPtr[4]); // 5 : 배열의 주소값이 들어있는 포인터 == 배열(주소값) 이기에 인덱싱으로 접근 가능하다

    printf("%d\n", sizeof(ArrPtr));

    return 0;
}

/*

printf("%d\n", sizeof(numArr));    // 40: sizeof로 배열의 크기를 구하면 배열이 메모리에 
                                   // 차지하는 공간이 출력됨

printf("%d\n", sizeof(numPtr));    // 4 : sizeof로 배열의 주소가 들어있는 포인터의 크기를 
                                   // 구하면 포인터의 크기가 출력됨(64비트라면 8)

*/