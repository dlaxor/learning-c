#include <stdio.h>

int main()
{
    int numArr[10] = { 1, 1, };
    // 이렇게 비워두면 나머지는 모두 0으로 된다

    printf("%d\n", numArr[0]);
    printf("%d\n", numArr[1]);
    printf("%d\n", numArr[2]);

    return 0;
}
