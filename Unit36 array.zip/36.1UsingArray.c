#include <stdio.h>

int main()
{
    int numArr[10] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
    // 배열의 크기는 초기화를 한다는 가정 하에 생략 가능하다

    printf("%d\n", numArr[1]);

    return 0;
}