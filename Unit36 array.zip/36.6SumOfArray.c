#include <stdio.h>

int main()
{
    int Arr1[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    int sum = 0;

    for (int i = 0; i < sizeof(Arr1) / sizeof(int); i++)
    {
        sum += Arr1[i];
    }

    printf("%d\n", sum);

    return 0;
}