#include <stdio.h>

// 포인터란?
// 주소를 저장하는 변수임
// 그 크기는 시스템 아키텍처(32비트 : 4바이트 / 64비트 : 8바이트)에 따라 정해진다!


int main()
{
    int num1 = 10;

    printf("%p\n", num1); // %p 아니면 %x

    return 0;
}

// 포인터 사용해보기