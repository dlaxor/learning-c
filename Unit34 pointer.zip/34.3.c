#include <stdio.h>

int main()
{
    int *numPtr;
    int num1 = 10;

    numPtr = &num1;

    *numPtr = 20;

    printf("%d\n", *numPtr); // 역참조 -> 20
    printf("%d\n", num1); // 실제 num1값도 바뀜 -> 20

    return 0;
}