#include <stdio.h>

int main()
{
    int *numPtr1; // 단일 포인터 선언
    int **numPtr2; // 이중 포인터 선언
    int num1 = 10;

    numPtr1 = &num1; // num1의 메모리 주소 저장

    numPtr2 = &numPtr1; // numPtr1의 메모리 주소 저장

    printf("%d\n", **numPtr2); // 10

    return 0;
}

// *의 개수에 따라서 삼중 포인터, 사중 포인터 그 이상도 만들 수 있음