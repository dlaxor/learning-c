// 변수의 메모리 주소를 구해보았다. 그럼 이 주소는 어디에 저장할까?
// -> 포인터 변수에!

#include <stdio.h>

int main()
{
    int *numPtr; // int *는 영어로 pointer to int라고 읽음
    // 그냥 int형 공간을 가리키는 포인터라는 뜻
    // 간단하게 int포인터라고도 부른다
    int num1 = 10;

    numPtr = &num1; // num1의 메모리 주소를 포인터변수에 저장

    printf("%p\n", numPtr);

    printf("%p\n", &num1);

    return 0;
}