#include <stdio.h>

// 여러 자료형의 포인터를 선언할 수 있다
// void 포인터란

int main()
{
    int num1 = 10;
    char c1 = 'a';
    
    int *numPtr1 = &num1;
    char *cPtr1 = &c1;

    void *ptr;

    ptr = numPtr1; // int 포인터에 void 포인터 저장
    ptr = cPtr1; // char 포인터에 void 포인터 저장
    // 그 역도 가능 (포인터 자료형이 달라도 컴파일 경고 X)

    // 하지만 자료형이 정해지지 않았기에 값을 가져오거나 저장할 크기 정해지지 않음
    // 따라서 포인터는 역참조를 할 수 없다
    // printf("%d", ptr); compile error

    return 0;
}