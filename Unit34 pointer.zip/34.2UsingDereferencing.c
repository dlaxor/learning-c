#include <stdio.h>

// 역참조 사용하기

int main()
{
    int num1 = 10;
    int *numPtr;

    numPtr = &num1;

    printf("%p\n", numPtr); // 주소
    printf("%p\n", &num1); // 주소
    printf("%d\n", *numPtr); // 역참조

    *numPtr = 20; // 역참조 연산자로 메모리 주소에 접근하여 20을 저장
    // *numPtr은 int형이고 num1도 int형이라 자료형이 일치함

    printf("%d\n", *numPtr); // 역참조 연산자로 메모리 주소에 접근하여 값을 가져옴
    printf("%d\n", num1); // 실제 num1의 값도 바뀜

    // numPtr = num1; // 컴파일 경고
    // numPtr은 int 포인터형이고 num1은 int형이라서 자료형이 일치하지 않음

    return 0;
}

/*
포인터를 선언할 때도 *를 사용하고 역참조를 할 때도 *를 사용한다.
같은 *기호를 사용해서 헷갈릴수도 있지만
그냥 서로 다른 용도이다.
선언할때 *는 이 변수가 포인터다라고 알려주는 역할이고
포인터에 사용할 때 *는 포인터가 메모리 주소를 역참조하겠다라는 뜻이다.
*/

/*
num1 값 가져오고 저장 가능
&num1 메모리 주소
*numPtr 값 가져오고 저장 가능
numPtr 메모리 주소
*/